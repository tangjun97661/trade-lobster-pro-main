import base64
import mimetypes
import os
import gradio as gr

from src.webui.webui_manager import WebuiManager
from src.webui.components.agent_settings_tab import create_agent_settings_tab
from src.webui.components.browser_settings_tab import create_browser_settings_tab
from src.webui.components.browser_use_agent_tab import create_browser_use_agent_tab
from src.webui.components.deep_research_agent_tab import create_deep_research_agent_tab

theme_map = {
    "Default": gr.themes.Default(),
    "Soft": gr.themes.Soft(),
    "Monochrome": gr.themes.Monochrome(),
    "Glass": gr.themes.Glass(),
    "Origin": gr.themes.Origin(),
    "Citrus": gr.themes.Citrus(),
    "Ocean": gr.themes.Ocean(),
    "Base": gr.themes.Base()
}


def get_logo_path():
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    candidates = [
        "/app/config/lobster-logo.png",
        "/app/config/lobster-logo.jpg",
        "/app/config/lobster-logo.jpeg",
        "/app/config/lobster-logo.webp",
        "/app/config/logo.png",
        "/app/config/logo.jpg",
        "/app/config/logo.jpeg",
        "/app/config/logo.webp",
        os.path.join(project_root, "assets", "lobster-logo.png"),
        os.path.join(project_root, "assets", "lobster-logo.jpg"),
        os.path.join(project_root, "assets", "lobster-logo.jpeg"),
        os.path.join(project_root, "assets", "lobster-logo.webp"),
        os.path.join(project_root, "assets", "logo.png"),
        os.path.join(project_root, "assets", "logo.jpg"),
        os.path.join(project_root, "assets", "logo.jpeg"),
        os.path.join(project_root, "assets", "logo.webp"),
        os.path.join(project_root, "assets", "web-ui.png"),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def get_logo_data_uri():
    logo_path = get_logo_path()
    if not logo_path:
        return None
    mime_type, _ = mimetypes.guess_type(logo_path)
    if not mime_type:
        mime_type = "image/png"
    with open(logo_path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime_type};base64,{encoded}"


def render_brand_html():
    logo_data_uri = get_logo_data_uri()
    if logo_data_uri:
        return f"""
        <div class="app-brand">
            <img src="{logo_data_uri}" alt="公共资源交易龙虾 Logo">
            <div class="app-brand-title">
                <h1>公共资源交易龙虾</h1>
                <p>南通公共资源交易大脑代理智能体</p>
            </div>
        </div>
        """
    return """
    <div class="app-brand">
        <div class="app-brand-title" style="text-align:center;">
            <h1>公共资源交易龙虾</h1>
            <p>南通公共资源交易大脑代理智能体</p>
        </div>
    </div>
    """


def create_ui(theme_name="Ocean"):
    css = """
    .gradio-container {
        width: 70vw !important; 
        max-width: 70% !important; 
        margin-left: auto !important;
        margin-right: auto !important;
        padding-top: 10px !important;
    }
    .header-text {
        text-align: center;
        margin-bottom: 20px;
    }
    .tab-header-text {
        text-align: center;
    }
    .app-brand {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 18px;
        margin-bottom: 20px;
    }
    .app-brand img {
        width: 140px;
        height: 140px;
        object-fit: contain;
        border-radius: 24px;
        box-shadow: 0 0 24px rgba(46, 214, 255, 0.35);
    }
    .app-brand-title {
        text-align: left;
    }
    .app-brand-title h1 {
        margin: 0;
        font-size: 2.2rem;
    }
    .app-brand-title p {
        margin: 8px 0 0;
        opacity: 0.9;
        font-size: 1.05rem;
    }
    .theme-section {
        margin-bottom: 10px;
        padding: 15px;
        border-radius: 10px;
    }
    """

    # dark mode in default
    js_func = """
    function refresh() {
        const url = new URL(window.location);

        if (url.searchParams.get('__theme') !== 'dark') {
            url.searchParams.set('__theme', 'dark');
            window.location.href = url.href;
        }
    }
    """

    ui_manager = WebuiManager()

    with gr.Blocks(
            title="交易龙虾Pro", theme=theme_map[theme_name], css=css, js=js_func,
    ) as demo:
        with gr.Row():
            brand_html = gr.HTML(render_brand_html())

        with gr.Tabs() as tabs:
            with gr.TabItem("⚙️ 智能体设置"):
                create_agent_settings_tab(ui_manager)

            with gr.TabItem("🌐 浏览器配置"):
                create_browser_settings_tab(ui_manager)

            with gr.TabItem("🤖 运行智能体"):
                create_browser_use_agent_tab(ui_manager)

            with gr.TabItem("🎁 智能体市场"):
                gr.Markdown(
                    """
                    ### 基于 交易龙虾Pro 的智能体集合
                    """,
                    elem_classes=["tab-header-text"],
                )
                with gr.Tabs():
                    with gr.TabItem("深度研究"):
                        create_deep_research_agent_tab(ui_manager)

        def _auto_load():
            try:
                ui_settings = ui_manager._read_persist()
            except Exception:
                ui_settings = {}
            updates = {}
            for comp_id, comp_val in (ui_settings or {}).items():
                comp = ui_manager.id_to_component.get(comp_id)
                if not comp:
                    continue
                updates[comp] = gr.update(value=comp_val)
            if updates:
                yield updates

        demo.load(fn=render_brand_html, outputs=brand_html)
        demo.load(fn=_auto_load, outputs=list(ui_manager.get_components()))

    return demo
